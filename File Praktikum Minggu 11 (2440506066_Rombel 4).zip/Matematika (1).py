phi = 3.14

def luas_lingkaran():
  jari = float(input("Masaukkan nilai jari-jari lingkaran: "))
  return phi * jari ** 2

def luas_persegi():
  sisi = float(input("Masukkan nilai sisi persegi: "))
  return sisi ** 2
